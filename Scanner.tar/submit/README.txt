Directory Includes:
    Scanner.java
    TokenReader.java
    Token.java
    testFiles/
        commentTest.txt
        errorTest.txt
        idMapTest.txt
        idTest.txt
        numTest.txt
        rwTest.txt
        stringTest.txt

